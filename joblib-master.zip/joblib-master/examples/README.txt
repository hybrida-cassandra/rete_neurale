.. _general_examples:

Examples
========

General examples
----------------

General-purpose and introductory examples for joblib.
